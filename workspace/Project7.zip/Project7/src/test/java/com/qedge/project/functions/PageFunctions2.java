package com.qedge.project.functions;

import com.qedge.project.lin.WebGeneric;

public class PageFunctions2 extends WebGeneric{
	/* Function 		: CreateAccount
	 * Parameters 		: No
	 * Description		: Create Account - External user
	 * Returns			: Void
	 */
	public static void createAccount(){
		
	}
	
	public static void login(){
		
	}
	
	public static void search(){
		
	}
	
	public static void addtoCart(){
		
	}
}
