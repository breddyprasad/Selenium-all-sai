package com.comname.proname.java;

public class Welcome {
	//Single line comment
//main + ctrl -space shortcut method for main method
public static void main(String[] args) {
	System.out.println("Welcome to Java");
	//syso + ctrl - space short cut for System.out.println()
	System.out.println("Welcome to Selenium");
}
}
