package com.comname.proname.java;

public class ExampleEncapsulation1 {
public static void main(String[] args) {
	ExampleEncapsulation ec2=new ExampleEncapsulation();
	ec2.setName("latha");
	System.out.println(ec2.getName());
}
}
