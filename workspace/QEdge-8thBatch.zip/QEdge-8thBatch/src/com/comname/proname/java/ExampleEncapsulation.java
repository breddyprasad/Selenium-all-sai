package com.comname.proname.java;

public class ExampleEncapsulation {
  private String name;

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
}
